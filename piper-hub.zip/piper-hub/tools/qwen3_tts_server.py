"""
Qwen3-TTS local microservice for Piper (stable baseline).

- CUDA only (no silent CPU fallback)
- No broken regex patches
- No infinite reload loops
- Clear error reporting
"""

import io
import os
import time
import traceback
import threading
from typing import Optional

import numpy as np
import torch
from fastapi import FastAPI, Body
from fastapi.responses import Response, JSONResponse
from pydantic import BaseModel


# ---------------- Config ----------------

HOST = os.environ.get("QWEN3_HOST", "127.0.0.1")
PORT = int(os.environ.get("QWEN3_PORT", "5005"))

DEVICE = os.environ.get("QWEN3_DEVICE", "cuda").lower()
CUDA_INDEX = int(os.environ.get("QWEN3_CUDA_INDEX", "0"))

MODEL_TYPE = os.environ.get("QWEN3_MODEL_TYPE", "CustomVoice")
MODEL_SIZE = os.environ.get("QWEN3_MODEL_SIZE", "0.6B")

DTYPE_ENV = os.environ.get("QWEN3_DTYPE", "float32").lower()

ATTN = os.environ.get("QWEN3_ATTN", "eager")

if DTYPE_ENV in ("float16", "fp16"):
    DTYPE = torch.float16
else:
    DTYPE = torch.float32


# ---------------- TLS Fix ----------------

def ensure_ca_bundle():
    for v in ("SSL_CERT_FILE", "REQUESTS_CA_BUNDLE", "CURL_CA_BUNDLE"):
        p = os.environ.get(v)
        if p and not os.path.exists(p):
            os.environ.pop(v, None)

    try:
        import certifi
        ca = certifi.where()
        if os.path.exists(ca):
            os.environ["SSL_CERT_FILE"] = ca
            os.environ["REQUESTS_CA_BUNDLE"] = ca
            os.environ["CURL_CA_BUNDLE"] = ca
    except Exception:
        pass


ensure_ca_bundle()


# ---------------- Qwen Import ----------------

try:
    from qwen_tts import Qwen3TTSModel
except Exception as e:
    Qwen3TTSModel = None
    IMPORT_ERR = e
else:
    IMPORT_ERR = None


# ---------------- Globals ----------------

app = FastAPI(title="Qwen3-TTS")

_model: Optional["Qwen3TTSModel"] = None
LOAD_ERROR: Optional[str] = None

INFER_LOCK = threading.Lock()

LAST_TB: Optional[str] = None
LAST_ERR: Optional[str] = None


# ---------------- Helpers ----------------

def model_id():
    return f"Qwen/Qwen3-TTS-12Hz-{MODEL_SIZE}-{MODEL_TYPE}"


def device_map():
    if DEVICE == "cuda":
        return f"cuda:{CUDA_INDEX}"
    return "cpu"


def load_model():

    global _model, LOAD_ERROR, LAST_ERR, LAST_TB

    if _model is not None:
        return _model

    if LOAD_ERROR:
        raise RuntimeError(LOAD_ERROR)

    if Qwen3TTSModel is None:
        raise RuntimeError(f"Import failed: {IMPORT_ERR}")

    mid = model_id()
    dmap = device_map()

    print(f"[qwen3] loading {mid} | {dmap} | {DTYPE}")

    try:
        _model = Qwen3TTSModel.from_pretrained(
            mid,
            device_map=dmap,
            dtype=DTYPE,
            attn_implementation=ATTN,
        )

        print("[qwen3] model ready")
        return _model

    except Exception as e:

        LAST_ERR = f"{type(e).__name__}: {e}"
        LAST_TB = traceback.format_exc()
        LOAD_ERROR = LAST_ERR

        print("[qwen3] LOAD ERROR:", LAST_ERR)
        print(LAST_TB)

        raise



def wav_bytes(sr, wav):

    import wave

    wav = np.asarray(wav, dtype=np.float32).flatten()
    wav = np.clip(wav, -1.0, 1.0)

    pcm = (wav * 32767).astype(np.int16)

    buf = io.BytesIO()

    with wave.open(buf, "wb") as wf:
        wf.setnchannels(1)
        wf.setsampwidth(2)
        wf.setframerate(int(sr))
        wf.writeframes(pcm.tobytes())

    return buf.getvalue()


# ---------------- API ----------------

class SpeakReq(BaseModel):

    text: str
    voice: str = "ryan"
    language: str = "english"
    instruct: str = "Neutral."


@app.get("/health")
def health():

    return {
        "ok": True,
        "device": DEVICE,
        "dtype": str(DTYPE),
        "model_loaded": _model is not None,
        "load_error": LOAD_ERROR,
    }

@app.get("/last_error")
def last_error():
    return {"ok": True, "error": LAST_ERR, "traceback": LAST_TB}


@app.post("/speak")
def speak(req: SpeakReq = Body(...)):

    text = (req.text or "").strip()

    if not text:
        return JSONResponse(400, {"ok": False, "error": "Empty text"})

    speaker = req.voice.lower().strip()
    language = req.language.lower().strip()
    instruct = req.instruct.strip()

    try:

        model = load_model()

        with INFER_LOCK, torch.inference_mode():

            if MODEL_TYPE.lower() == "customvoice":

                wavs, sr = model.generate_custom_voice(
                    text=text,
                    language=language,
                    speaker=speaker,
                    instruct=instruct,
                )

                wav = wavs[0]

            else:

                wavs, sr = model.generate(
                    text=text,
                    language=language,
                    instruct=instruct,
                )

                wav = wavs[0]

        if torch.is_tensor(wav):
            wav = wav.float().cpu().numpy()

        audio = wav_bytes(sr or 24000, wav)

        return Response(audio, media_type="audio/wav")

    except Exception as e:

        print("[qwen3] ERROR:")
        traceback.print_exc()

        return JSONResponse(
            500,
            {"ok": False, "error": str(e)}
        )


# ---------------- Main ----------------

if __name__ == "__main__":

    import uvicorn

    uvicorn.run(app, host=HOST, port=PORT)

// app.js — main Piper UI logic (split from index.html)

const log = document.getElementById("log");
const f = document.getElementById("f");
const t = document.getElementById("t");
const talk = document.getElementById("talk");
const off = document.getElementById("off");
const readOnly = document.getElementById("readOnly");
const devMode = document.getElementById("devMode");

const actionsWrap = document.getElementById("actionsWrap");
const actionsList = document.getElementById("actionsList");
const historyList = document.getElementById("historyList");
const runlogList = document.getElementById("runlogList");

// Voice UI
const voiceBtn = document.getElementById("voiceBtn");
const voicePanel = document.getElementById("voicePanel");
const voiceSelect = document.getElementById("voiceSelect");
const jarvisMode = document.getElementById("jarvisMode");
const voiceRefresh = document.getElementById("voiceRefresh");

localStorage.setItem("piper_sessionId", window.sessionId);

// Dev Mode state (client-side)
// - Stored in localStorage
// - Sent to the backend on each chat request (safe for older servers that ignore it)
// - Can be toggled by saying "Activate Dev Mode" / "Deactivate Dev Mode"
try {
  const saved = localStorage.getItem("piper_devMode");
  if (saved === "1") devMode.checked = true;
} catch {}

function setDevMode(on) {
  if (!devMode) return;
  devMode.checked = !!on;
  try {
    localStorage.setItem("piper_devMode", on ? "1" : "0");
  } catch {}
}

// Persist <details> open state per action id
const openDetails = new Set(
  JSON.parse(localStorage.getItem("piper_openDetails") || "[]"),
);

// Hard-coded voice choices (provider + voice)
const VOICE_CHOICES = [
  // ---- Qwen modes ----
  {
    id: "qwen_default_female",
    label: "Qwen – Default Female",
    provider: "qwen3",
    voice: "vivian",
    qwenMode: "default_female",
  },
  {
    id: "qwen_custom",
    label: "Qwen – Custom Voice",
    provider: "qwen3",
    voice: "custom",
    qwenMode: "custom",
  },
  {
    id: "qwen_imitation",
    label: "Qwen – Imitation Voice",
    provider: "qwen3",
    voice: "imitation",
    qwenMode: "imitation",
  },

  // ---- Piper voices ----
  { id: "amy", label: "Amy", provider: "piper", voice: "amy" },
  { id: "jarvis", label: "Jarvis", provider: "piper", voice: "jarvis" },
  { id: "alba", label: "Alba", provider: "piper", voice: "alba" },
];

function choiceById(id) {
  return VOICE_CHOICES.find((v) => v.id === id) || VOICE_CHOICES[0];
}

// Voice state
let lastNonJarvisVoice = localStorage.getItem("piper_lastNonJarvisVoice") || "";

// ---- Voice UI logic ----
async function api(path, body) {
  const r = await fetch(path, {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify(body || {}),
  });
  const j = await r.json().catch(() => null);
  if (!r.ok)
    throw new Error(
      (j && (j.error || j.message)) || r.status + " " + r.statusText,
    );
  return j;
}

async function fetchVoiceConfig() {
  const r = await fetch("/voice/config", { cache: "no-store" });
  const j = await r.json().catch(() => null);
  if (!r.ok) throw new Error("Failed to load voice config.");

  if (j && j.ok && j.config) return j.config;
  if (j && typeof j === "object" && ("provider" in j || "voice" in j)) return j;

  throw new Error("Failed to load voice config.");
}

function fillVoiceSelect(selectedId) {
  voiceSelect.innerHTML = "";
  for (const v of VOICE_CHOICES) {
    const opt = document.createElement("option");
    opt.value = v.id;
    opt.textContent = v.label;
    voiceSelect.appendChild(opt);
  }
  voiceSelect.value = VOICE_CHOICES.some((v) => v.id === selectedId)
    ? selectedId
    : VOICE_CHOICES[0].id;
}

async function applyVoice(choiceId) {
  const c = choiceById(choiceId);

  const body =
    c.provider === "qwen3"
      ? { provider: "qwen3", voice: c.voice, qwen3: { mode: c.qwenMode } }
      : { provider: c.provider, voice: c.voice };

  const out = await api("/voice/config", body);

  const provider = out?.config?.provider || c.provider;
  const voice = out?.config?.voice || c.voice;

  voiceBtn.textContent = `🔊 ${c.label}`;
  jarvisMode.checked = provider === "piper" && voice === "jarvis";

  if (!(provider === "piper" && voice === "jarvis")) {
    lastNonJarvisVoice = choiceId;
    localStorage.setItem("piper_lastNonJarvisVoice", lastNonJarvisVoice);
  }
}

async function initVoiceUI() {
  try {
    const cfg = await fetchVoiceConfig();
    let selected = "amy";
    if (cfg.provider === "piper" && cfg.voice === "jarvis") selected = "jarvis";
    if (cfg.provider === "chatterbox") selected = "piper";
    if (cfg.provider === "piper" && cfg.voice === "alba") selected = "alba";

    fillVoiceSelect(selected);
    voiceBtn.textContent = `🔊 ${choiceById(selected).label}`;
    jarvisMode.checked = selected === "jarvis";
  } catch (e) {
    console.warn("voice ui init failed", e);
    fillVoiceSelect("amy");
    voiceBtn.textContent = "🔊 Amy";
    jarvisMode.checked = false;
  }
}

// Open/close menu
voiceBtn.onclick = (e) => {
  e.preventDefault();
  e.stopPropagation();
  const open = voicePanel.style.display !== "none";
  voicePanel.style.display = open ? "none" : "block";
};

document.addEventListener("click", (e) => {
  if (!voicePanel) return;
  if (voicePanel.style.display === "none") return;
  const vw = voiceBtn.closest(".voiceWrap");
  if (vw && !vw.contains(e.target)) {
    voicePanel.style.display = "none";
  }
});

voiceRefresh.onclick = async () => {
  try {
    const cfg = await fetchVoiceConfig();
    let selected = "amy";
    if (cfg.provider === "piper" && cfg.voice === "jarvis") selected = "jarvis";
    if (cfg.provider === "chatterbox") selected = "piper";
    if (cfg.provider === "piper" && cfg.voice === "alba") selected = "alba";

    fillVoiceSelect(selected);
    voiceBtn.textContent = `🔊 ${choiceById(selected).label}`;
    jarvisMode.checked = selected === "jarvis";
  } catch (e) {
    alert("Failed to refresh voices: " + e);
  }
};

voiceSelect.onchange = async () => {
  try {
    await applyVoice(voiceSelect.value);
  } catch (e) {
    alert("Failed to set voice: " + e);
  }
};

jarvisMode.onchange = async () => {
  if (jarvisMode.checked) {
    voiceSelect.value = "jarvis";
    await applyVoice("jarvis");
  } else {
    const restore = lastNonJarvisVoice || "amy";
    voiceSelect.value = restore;
    await applyVoice(restore);
  }
};

// Dev Mode checkbox persistence
if (devMode) {
  devMode.onchange = () => {
    setDevMode(devMode.checked);
  };
}

// ---- Utilities ----
function hookDetailsPersistence(cardEl, actionId) {
  const details = cardEl.querySelectorAll("details[data-kind]");
  details.forEach((d) => {
    const key = `${actionId}:${d.getAttribute("data-kind")}`;
    if (openDetails.has(key)) d.open = true;

    d.addEventListener(
      "toggle",
      () => {
        if (d.open) openDetails.add(key);
        else openDetails.delete(key);
        localStorage.setItem(
          "piper_openDetails",
          JSON.stringify(Array.from(openDetails)),
        );
      },
      { passive: true },
    );
  });
}

function badgeClass(status) {
  return [
    "pending",
    "running",
    "done",
    "failed",
    "rejected",
    "rolled_back",
    "approved",
  ].includes(status)
    ? status
    : "pending";
}
function fmtTime(ms) {
  try {
    return new Date(ms).toLocaleString();
  } catch {
    return "";
  }
}
function esc(s) {
  return String(s).replaceAll("<", "&lt;");
}

function add(who, msg, meta) {
  const row = document.createElement("div");
  row.className = "msg " + who;

  const whoEl = document.createElement("div");
  whoEl.className = "who";
  whoEl.textContent = who === "me" ? "You" : "Piper";

  const bubble = document.createElement("div");
  bubble.className = "bubble";
  bubble.innerHTML = String(msg).replaceAll("\n", "<br>");

  if (meta) {
    // String meta (legacy)
    if (typeof meta === "string") {
      const m = document.createElement("div");
      m.className = "metaLine";
      m.textContent = meta;
      bubble.appendChild(m);
    }

    // Structured meta (Phase 1.1+)
    if (typeof meta === "object" && meta.locationMatches) {
      const lm = meta.locationMatches;
      const box = document.createElement("div");
      box.className = "locMatches";

      const title = document.createElement("div");
      title.className = "locMatchesTitle";
      title.textContent = `Matches for "${lm.query}"`;
      box.appendChild(title);

      const ul = document.createElement("ul");
      ul.className = "locMatchesList";
      for (const m of lm.shown || []) {
        const li = document.createElement("li");
        li.textContent = `${m.file}:${m.line}:${m.col} ${String(m.preview || "").trim()}`;
        ul.appendChild(li);
      }
      box.appendChild(ul);

      const hidden = Array.isArray(lm.hidden) ? lm.hidden : [];
      if (hidden.length > 0) {
        const moreBtn = document.createElement("button");
        moreBtn.className = "btn btn-ghost btn-small";
        moreBtn.type = "button";
        moreBtn.textContent = `Show more (${hidden.length})`;

        const more = document.createElement("div");
        more.className = "locMatchesMore";
        more.style.display = "none";

        const ul2 = document.createElement("ul");
        ul2.className = "locMatchesList";
        for (const m of hidden) {
          const li = document.createElement("li");
          li.textContent = `${m.file}:${m.line}:${m.col} ${String(m.preview || "").trim()}`;
          ul2.appendChild(li);
        }
        more.appendChild(ul2);

        moreBtn.addEventListener("click", () => {
          const open = more.style.display !== "none";
          more.style.display = open ? "none" : "block";
          moreBtn.textContent = open
            ? `Show more (${hidden.length})`
            : "Show less";
        });

        box.appendChild(moreBtn);
        box.appendChild(more);
      }

      bubble.appendChild(box);
    }

    // Structured sources (Phase 2.1)
    if (
      typeof meta === "object" &&
      meta.sources &&
      (meta.sources.shown || []).length
    ) {
      const s = meta.sources;
      const box = document.createElement("div");
      box.className = "sourcesBox";

      const head = document.createElement("div");
      head.className = "sourcesHead";
      head.textContent = "Sources";
      box.appendChild(head);

      const ul = document.createElement("ul");
      ul.className = "sourcesList";
      for (const it of s.shown || []) {
        const li = document.createElement("li");
        const a = document.createElement("a");
        a.href = it.url;
        a.target = "_blank";
        a.rel = "noreferrer";
        a.textContent = it.title || it.url;
        li.appendChild(a);
        ul.appendChild(li);
      }
      box.appendChild(ul);

      const hidden = Array.isArray(s.hidden) ? s.hidden : [];
      if (hidden.length > 0) {
        const moreBtn = document.createElement("button");
        moreBtn.className = "btn btn-ghost btn-small";
        moreBtn.type = "button";
        moreBtn.textContent = `Show more (${hidden.length})`;

        const more = document.createElement("div");
        more.className = "sourcesMore";
        more.style.display = "none";

        const ul2 = document.createElement("ul");
        ul2.className = "sourcesList";
        for (const it of hidden) {
          const li = document.createElement("li");
          const a = document.createElement("a");
          a.href = it.url;
          a.target = "_blank";
          a.rel = "noreferrer";
          a.textContent = it.title || it.url;
          li.appendChild(a);
          ul2.appendChild(li);
        }
        more.appendChild(ul2);

        moreBtn.addEventListener("click", () => {
          const open = more.style.display !== "none";
          more.style.display = open ? "none" : "block";
          moreBtn.textContent = open
            ? `Show more (${hidden.length})`
            : "Show less";
        });

        box.appendChild(moreBtn);
        box.appendChild(more);
      }

      bubble.appendChild(box);
    }
  }

  row.appendChild(whoEl);
  row.appendChild(bubble);
  log.appendChild(row);
  log.scrollTop = log.scrollHeight;
  return row;
}
function remove(node) {
  try {
    node && node.remove && node.remove();
  } catch {}
}

// ---- Run Log ----
async function fetchRunLog() {
  const r = await fetch("/runlog?limit=200", { cache: "no-store" });
  const j = await r.json().catch(() => null);
  if (!(j && j.ok && Array.isArray(j.events))) return [];
  return j.events;
}

function renderRunLog(list) {
  if (!runlogList) return;
  runlogList.innerHTML = "";
  for (const e of list) {
    const d = document.createElement("div");
    d.className = "card card-small";
    const when = fmtTime(e.ts);
    const kind = esc(String(e.kind || "event"));
    const meta = esc(JSON.stringify({ ...e, ts: undefined }, null, 2));
    d.innerHTML = `
      <h4>
        <span>${kind}</span>
        <span class="badge">${when}</span>
      </h4>
      <details data-kind="payload">
        <summary>View details</summary>
        <pre>${meta}</pre>
      </details>
    `;
    runlogList.appendChild(d);
  }
}

// ---- Actions ----
async function fetchAllActions() {
  const r = await fetch("/actions", { cache: "no-store" });
  const j = await r.json().catch(() => null);
  if (!(j && j.ok && Array.isArray(j.actions)))
    throw new Error("Failed to load actions.");
  return j.actions;
}

function renderPending(pending) {
  actionsWrap.style.display = pending.length ? "block" : "none";
  actionsList.innerHTML = "";

  for (const a of pending) {
    const d = document.createElement("div");
    d.className = "card";

    const payloadPretty = JSON.stringify(a.payload || {}, null, 2);
    const reason = a.reason ? a.reason : "";
    const canPreview = [
      "apply_patch",
      "write_file",
      "mkdir",
      "bundle",
      "set_html_title",
    ].includes(a.type);
    const previewHref = "/action/preview/" + a.id;

    d.innerHTML = `
      <h4>
        <span>${esc(a.title || a.type)}</span>
        <span class="badge ${badgeClass(a.status)}">${esc(a.status)}</span>
      </h4>

      <div class="kv">
        <span>Type: <code>${esc(a.type)}</code></span>
        <span>Created: ${fmtTime(a.createdAt)}</span>
      </div>

      ${reason ? `<div class="kv" style="margin-top:6px;"><span><b>Why:</b> ${esc(reason)}</span></div>` : ``}

      <details data-kind="payload">
        <summary>View details</summary>
        <pre>${esc(payloadPretty)}</pre>
      </details>

      <div class="btnRow">
        <button class="btn-primary" data-act="approve">Approve</button>
        <button class="btn-secondary" data-act="reject">Reject</button>
        ${canPreview ? `<a class="btn-secondary" href="${previewHref}" target="_blank" rel="noopener">Preview</a>` : ``}
      </div>
    `;

    hookDetailsPersistence(d, a.id);

    const approveBtn = d.querySelector('[data-act="approve"]');
    const rejectBtn = d.querySelector('[data-act="reject"]');

    approveBtn.onclick = async () => {
      try {
        approveBtn.disabled = true;
        const note =
          prompt("Optional note for approval (leave blank for none):") || "";
        // Dry-run toggle removed. Approvals always execute real actions.
        await api("/action/approve", { id: a.id, note, dryRun: false });
        add("piper", "Approved.");
        await window.piperSpeak("Approved.");
        refreshActions(true);
        refreshRunLog();
      } catch (e) {
        alert("Approve failed: " + e);
      } finally {
        approveBtn.disabled = false;
      }
    };

    rejectBtn.onclick = async () => {
      try {
        rejectBtn.disabled = true;
        const note = prompt("Why reject this action?") || "";
        await api("/action/reject", { id: a.id, note });
        add("piper", "Rejected.");
        await window.piperSpeak("Rejected.");
        refreshActions(true);
        refreshRunLog();
      } catch (e) {
        alert("Reject failed: " + e);
      } finally {
        rejectBtn.disabled = false;
      }
    };

    actionsList.appendChild(d);
  }
}

function renderHistory(list) {
  historyList.innerHTML = "";
  for (const a of list) {
    const d = document.createElement("div");
    d.className = "card card-small";

    const payloadPretty = JSON.stringify(a.payload || {}, null, 2);
    const note = a.note ? a.note : "";

    const canPreview = [
      "apply_patch",
      "write_file",
      "mkdir",
      "bundle",
      "set_html_title",
    ].includes(a.type);
    const previewHref = "/action/preview/" + a.id;

    const canRollback =
      a.status === "approved" || a.status === "done" || a.status === "failed";

    d.innerHTML = `
      <h4>
        <span>${esc(a.title || a.type)}</span>
        <span class="badge ${badgeClass(a.status)}">${esc(a.status)}</span>
      </h4>

      <div class="kv">
        <span>Type: <code>${esc(a.type)}</code></span>
        <span>Updated: ${fmtTime(a.updatedAt || a.createdAt)}</span>
      </div>

      ${note ? `<div class="kv" style="margin-top:6px;"><span><b>Note:</b> ${esc(note)}</span></div>` : ``}

      <details data-kind="payload">
        <summary>View details</summary>
        <pre>${esc(payloadPretty)}</pre>
      </details>

      <div class="btnRow">
        ${canPreview ? `<a class="btn-secondary" href="${previewHref}" target="_blank" rel="noopener">Preview</a>` : ``}
        ${canRollback ? `<button class="btn-secondary" data-act="rollback">Rollback</button>` : ``}
      </div>
    `;

    hookDetailsPersistence(d, a.id);

    const rollbackBtn = d.querySelector('[data-act="rollback"]');
    if (rollbackBtn) {
      rollbackBtn.onclick = async () => {
        try {
          rollbackBtn.disabled = true;
          const ok = confirm("Rollback this action?");
          if (!ok) return;

          // Dry-run toggle removed. Rollbacks run for real.
          const res = await api("/action/rollback", {
            id: a.id,
            dryRun: false,
          });
          const msg = res && res.ok ? "✅ Rolled back." : "Rollback finished.";
          add("piper", msg);
          await window.piperSpeak(msg);
          refreshActions(true);
          refreshRunLog();
        } catch (e) {
          alert("Rollback failed: " + e);
        } finally {
          rollbackBtn.disabled = false;
        }
      };
    }

    historyList.appendChild(d);
  }
}

let lastSig = "";

function signatureForActions(list) {
  return list
    .map((a) => `${a.id}:${a.status}:${a.updatedAt || a.createdAt}`)
    .join("|");
}

async function refreshRunLog() {
  try {
    const events = await fetchRunLog();
    renderRunLog(events);
  } catch (e) {
    console.warn("refreshRunLog failed:", e);
  }
}

async function refreshActions(force) {
  try {
    const all = await fetchAllActions();

    const pending = all.filter((a) => a.status === "pending");
    const recent = all
      .slice()
      .sort(
        (a, b) =>
          (b.updatedAt || b.createdAt || 0) - (a.updatedAt || a.createdAt || 0),
      )
      .slice(0, 10);

    const sig = signatureForActions(all);
    if (!force && sig === lastSig) return;
    lastSig = sig;

    renderPending(pending);
    renderHistory(recent);
  } catch (e) {
    console.warn("refreshActions failed:", e);
  }
}

// ---- Chat ----
async function sendToChat(text) {
  return await api("/chat", {
    sessionId: window.sessionId,
    message: text,
    readOnly: readOnly.checked,
    devMode: !!(devMode && devMode.checked),
    userInitiated: true,
    metBefore: localStorage.getItem("piper.metBefore") === "1",
  });
}

f.onsubmit = async (e) => {
  e.preventDefault();
  const msg = t.value.trim();
  if (!msg) return;

  // ----------------------
  // Dev Mode voice command
  // ----------------------
  // Keep this deterministic and local to avoid confusing planner/chat routing.
  // Backend still receives devMode on subsequent messages via sendToChat.
  if (/^\s*(activate|enable|turn on)\s+dev\s*mode\s*\.?\s*$/i.test(msg)) {
    t.value = "";
    add("me", msg);
    setDevMode(true);
    add("piper", "Dev Mode engaged, sir.");
    await window.piperSpeak("Dev Mode engaged, sir.", "confident", 0.45);
    return;
  }
  if (/^\s*(deactivate|disable|turn off)\s+dev\s*mode\s*\.?\s*$/i.test(msg)) {
    t.value = "";
    add("me", msg);
    setDevMode(false);
    add("piper", "Dev Mode disengaged, sir.");
    await window.piperSpeak("Dev Mode disengaged, sir.", "neutral", 0.35);
    return;
  }

  t.value = "";
  add("me", msg);

  const thinkingNode = add("piper", "🧠 Thinking…");

  try {
    const c = await sendToChat(msg);
    remove(thinkingNode);

    add("piper", c.reply, c.meta);

    // (debugEmotion removed)

    const queued =
      !readOnly.checked &&
      c.proposed &&
      Array.isArray(c.proposed) &&
      c.proposed.length > 0;

    if (queued) {
      // Show what was proposed in chat so it is never ambiguous
      try {
        const titles = c.proposed.map((p) => p.title || p.type).slice(0, 6);
        const more =
          c.proposed.length > titles.length
            ? ` (+${c.proposed.length - titles.length} more)`
            : "";
        add(
          "piper",
          `🧾 Action(s) proposed: ${titles.map((t) => `“${t}”`).join(", ")}${more}`,
        );
      } catch {}

      await window.piperSpeak("Queued for approval.", "confident", 0.45);
    } else {
      await window.piperSpeak(c.reply, c.emotion, c.intensity);
    }

    if (queued) refreshActions(true);
    refreshRunLog();
  } catch (e) {
    remove(thinkingNode);
    add("piper", "⚠️ Something went wrong. Try again.");
    console.warn("chat failed:", e);
  }
};

if (off)
  off.onclick = async () => {
    const ok = confirm("Turn Piper off? (This stops the server)");
    if (!ok) return;
    try {
      off.disabled = true;
      add("piper", "🛑 Shutting down…");
      await fetch("/shutdown", { method: "POST" });
      add("piper", "Server stopped. Start Piper again to use this page.");
    } catch (e) {
      add("piper", "Shutdown failed: " + e);
    } finally {
      off.disabled = false;
    }
  };

// 🎤 Talk: silence detection
talk.onclick = async () => {
  talk.disabled = true;
  add("piper", "🎤 Listening…");

  let stream,
    recorder,
    chunks = [];
  let audioCtx, analyser, data;
  let started = false,
    silence = 0;

  const THRESH = 0.012;
  const STOP_MS = 350;
  const CHECK = 20;

  try {
    stream = await navigator.mediaDevices.getUserMedia({ audio: true });
    recorder = new MediaRecorder(stream);
    recorder.ondataavailable = (e) => e.data.size && chunks.push(e.data);

    audioCtx = new (window.AudioContext || window.webkitAudioContext)();
    const src = audioCtx.createMediaStreamSource(stream);
    analyser = audioCtx.createAnalyser();
    analyser.fftSize = 2048;
    src.connect(analyser);
    data = new Uint8Array(analyser.fftSize);

    recorder.start(100);

    const iv = setInterval(() => {
      analyser.getByteTimeDomainData(data);
      let sum = 0;
      for (let i = 0; i < data.length; i++) {
        const v = (data[i] - 128) / 128;
        sum += v * v;
      }
      const rms = Math.sqrt(sum / data.length);
      if (rms > THRESH) started = true;

      if (started) {
        silence = rms < THRESH ? silence + CHECK : 0;
        if (silence >= STOP_MS) {
          clearInterval(iv);
          recorder.stop();
        }
      }
    }, CHECK);

    const blob = await new Promise(
      (r) =>
        (recorder.onstop = () => r(new Blob(chunks, { type: "audio/webm" }))),
    );

    try {
      stream.getTracks().forEach((t) => t.stop());
    } catch {}
    try {
      audioCtx && audioCtx.close && audioCtx.close();
    } catch {}

    add("piper", "📝 Transcribing…");

    const fd = new FormData();
    fd.append("audio", blob, "mic.webm");
    const tr = await fetch("/voice/transcribe", { method: "POST", body: fd });
    const tj = await tr.json().catch(() => null);
    const text = tj && tj.ok ? tj.text : "";
    if (!text) {
      add("piper", "⚠️ No transcript.");
      return;
    }

    add("me", text, "voice");
    const thinkingNode = add("piper", "🧠 Thinking…");

    const c = await sendToChat(text);
    remove(thinkingNode);

    add("piper", c.reply);

    const queued =
      !readOnly.checked &&
      c.proposed &&
      Array.isArray(c.proposed) &&
      c.proposed.length > 0;
    if (queued) {
      // Show what was proposed in chat so it is never ambiguous
      try {
        const titles = c.proposed.map((p) => p.title || p.type).slice(0, 6);
        const more =
          c.proposed.length > titles.length
            ? ` (+${c.proposed.length - titles.length} more)`
            : "";
        add(
          "piper",
          `🧾 Action(s) proposed: ${titles.map((t) => `“${t}”`).join(", ")}${more}`,
        );
      } catch {}

      await window.piperSpeak("Queued for approval.", "confident", 0.45);
    } else {
      await window.piperSpeak(c.reply, c.emotion, c.intensity);
    }

    if (queued) refreshActions(true);
    refreshRunLog();
  } catch (e) {
    console.warn("talk flow failed:", e);
    add("piper", "⚠️ Voice input failed. Check console.");
  } finally {
    talk.disabled = false;
  }
};

// Boot
initVoiceUI();
refreshActions(true);
refreshRunLog();
setInterval(() => refreshActions(false), 1200);

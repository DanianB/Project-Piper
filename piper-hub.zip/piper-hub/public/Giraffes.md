# Giraffes
A giraffe is a tall, even-toed mammal with a distinctive coat pattern and long neck.

They are known for their ability to reach high into trees to feed on leaves and fruits.
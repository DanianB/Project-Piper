# start-piper.ps1 — Piper Supervisor (XTTS)
# PowerShell 5.1 compatible. ASCII-only.
# Starts:
#   1) XTTS Flask server (optional)
#   2) Node Piper Hub
#
# Env knobs:
#   PIPER_DISABLE_XTTS=1            -> do not start XTTS
#   XTTS_PYTHON                     -> python.exe for XTTS (defaults to E:\AI\CurieXTTS\venv_xtts\Scripts\python.exe)
#   XTTS_MODEL_DIR                  -> model folder (defaults to E:\AI\piper_voice_curie)
#   XTTS_REFS_DIR                   -> refs folder (defaults to <XTTS_MODEL_DIR>\refs)
#   XTTS_PORT                       -> port (defaults to 5055)
#   PIPER_WAIT_XTTS_HEALTH=1         -> wait for /health before starting hub
#   PIPER_XTTS_HEALTH_TIMEOUT=90     -> seconds (default 60)
#   PIPER_NODE_EXE                  -> node.exe (defaults to "C:\Program Files\nodejs\node.exe")

$ErrorActionPreference = 'Continue'
$PiperDir = Split-Path -Parent $PSCommandPath

function PauseExit([int]$code, [string]$msg) {
  Write-Host $msg
  Write-Host 'Press ENTER to exit...'
  Read-Host | Out-Null
  exit $code
}

function Wait-ForUrl([string]$url, [int]$timeoutSec) {
  if (-not $timeoutSec -or $timeoutSec -le 0) { $timeoutSec = 30 }
  $deadline = (Get-Date).AddSeconds($timeoutSec)
  while ((Get-Date) -lt $deadline) {
    try { return Invoke-RestMethod -Uri $url -Method Get -TimeoutSec 2 }
    catch { Start-Sleep -Milliseconds 250 }
  }
  return $null
}

# ----- paths / logs -----
$LogDir = Join-Path $PiperDir 'data\logs'
if (-not (Test-Path $LogDir)) { New-Item -ItemType Directory -Force -Path $LogDir | Out-Null }

$hubLog = Join-Path $LogDir 'hub.log'
$xttsOut = Join-Path $LogDir 'xtts.out.log'
$xttsErr = Join-Path $LogDir 'xtts.err.log'
try { Remove-Item $hubLog, $xttsOut, $xttsErr -ErrorAction SilentlyContinue } catch {}

# ----- start XTTS (optional) -----
$XttsProc = $null
$XttsEnabled = $true
if ($env:PIPER_DISABLE_XTTS -eq '1') { $XttsEnabled = $false }

if ($XttsEnabled) {
  $XttsPython = $env:XTTS_PYTHON
  if (-not $XttsPython -or $XttsPython.Trim() -eq '') { $XttsPython = 'E:\AI\CurieXTTS\venv_xtts\Scripts\python.exe' }

  $XttsModelDir = $env:XTTS_MODEL_DIR
  if (-not $XttsModelDir -or $XttsModelDir.Trim() -eq '') { $XttsModelDir = 'E:\AI\piper_voice_curie' }

  $XttsRefsDir = $env:XTTS_REFS_DIR
  if (-not $XttsRefsDir -or $XttsRefsDir.Trim() -eq '') { $XttsRefsDir = Join-Path $XttsModelDir 'refs' }

  $XttsPort = $env:XTTS_PORT
  if (-not $XttsPort -or $XttsPort.Trim() -eq '') { $XttsPort = '5055' }

  $env:XTTS_MODEL_DIR = $XttsModelDir
  $env:XTTS_REFS_DIR  = $XttsRefsDir
  $env:XTTS_PORT      = $XttsPort

  $XttsUrl = 'http://127.0.0.1:' + $XttsPort
  $env:XTTS_URL = $XttsUrl

  $XttsScript = Join-Path $PiperDir 'tools\xtts_server.py'
  if (-not (Test-Path $XttsPython)) { PauseExit 1 ("ERROR: XTTS python not found: {0}" -f $XttsPython) }
  if (-not (Test-Path $XttsScript)) { PauseExit 1 ("ERROR: XTTS server script not found: {0}" -f $XttsScript) }

  Write-Host ("Starting XTTS via: {0}" -f $XttsPython)
  Write-Host ("XTTS URL: {0}" -f $XttsUrl)
  Write-Host ("Model: {0}" -f $XttsModelDir)
  Write-Host ("Refs:  {0}" -f $XttsRefsDir)
  Write-Host ("Logging: {0} and {1}" -f $xttsOut, $xttsErr)

  $XttsProc = Start-Process `
    -FilePath $XttsPython `
    -ArgumentList @("$XttsScript") `
    -WorkingDirectory $PiperDir `
    -PassThru `
    -WindowStyle Hidden `
    -RedirectStandardOutput $xttsOut `
    -RedirectStandardError $xttsErr

  Start-Sleep -Milliseconds 500

  if ($env:PIPER_WAIT_XTTS_HEALTH -eq '1') {
    $t = 60
    if ($env:PIPER_XTTS_HEALTH_TIMEOUT) {
      try { $t = [int]$env:PIPER_XTTS_HEALTH_TIMEOUT } catch { $t = 60 }
    }
    $health = Wait-ForUrl ($XttsUrl + '/health') $t
    if ($null -ne $health) {
      Write-Host ("XTTS health: device={0} ready={1}" -f $health.device, $health.ready)
    } else {
      Write-Host ("WARNING: XTTS did not become healthy in time. Check logs:`n  {0}" -f $xttsErr)
    }
  } else {
    Write-Host "XTTS started (not waiting for /health)."
  }

  Write-Host ''
}

function Stop-XttsIfRunning() {
  try {
    if ($XttsProc -and -not $XttsProc.HasExited) {
      Stop-Process -Id $XttsProc.Id -Force -ErrorAction SilentlyContinue
    }
  } catch {}
}

$global:__piper_cleaned = $false
Register-EngineEvent PowerShell.Exiting -Action {
  if (-not $global:__piper_cleaned) {
    $global:__piper_cleaned = $true
    try { Stop-XttsIfRunning } catch {}
  }
} | Out-Null

# ----- start Node hub -----
$NodeExe = $env:PIPER_NODE_EXE
if (-not $NodeExe -or $NodeExe.Trim() -eq '') { $NodeExe = 'C:\Program Files\nodejs\node.exe' }

$EntryAbs = Join-Path $PiperDir 'src\server.js'
if (-not (Test-Path $NodeExe)) { PauseExit 1 ("ERROR: node.exe not found: {0}" -f $NodeExe) }
if (-not (Test-Path $EntryAbs)) { PauseExit 1 ("ERROR: Entry not found: {0}" -f $EntryAbs) }

while ($true) {
  Set-Location -Path $PiperDir
  Write-Host ("Starting Piper... {0}" -f (Get-Date))

  $code = 1
  try { & $NodeExe $EntryAbs; $code = $LASTEXITCODE }
  catch { Write-Host ("Node launch error: {0}" -f $_.Exception.Message); $code = 1 }

  Write-Host ("Piper stopped (exit code {0})." -f $code)

  # Always stop XTTS when Piper stops
  Stop-XttsIfRunning

  if ($code -eq 0) {
    Write-Host 'Restart requested. Relaunching...'
    Start-Sleep -Milliseconds 600
    Write-Host ''
    continue
  }

  Write-Host 'Piper exited unexpectedly. Press ENTER to restart (or Ctrl+C to quit).'
  Read-Host | Out-Null
  Write-Host ''
}

// src/routes/chat.js
// Thin shim: keep server.js imports stable while the chat route is modularized.
export { chatRoutes } from "./chat/index.js";
export { default } from "./chat/index.js";

// src/routes/chat/constants.js

// Keep UI/render logic simple: always the same shape.
export const EMPTY_SOURCES = { total: 0, shown: [], hidden: [] };

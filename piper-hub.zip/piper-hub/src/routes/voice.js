import { Router } from "express";
import express from "express";
import multer from "multer";
import fs from "fs";
import path from "path";
import { fileURLToPath } from "url";
import { spawn } from "child_process";
import { transcribeAudioBuffer } from "../services/voice/stt.js";
import { wavToPcm16le } from "../services/voice/wav_pcm.js";
import { PIPER_EXE } from "../config/paths.js";

/**
 * Voice routes (Chatterbox removed for now).
 *
 * Providers supported here:
 *   - qwen3 (alias: qwen): calls local Qwen3 TTS microservice (http://127.0.0.1:5005 by default)
 *   - piper: runs local piper.exe as a fallback (default voice: alba)
 *
 * Endpoints:
 *   POST /voice/speak   -> returns audio/wav
 *   POST /voice/stream  -> returns framed PCM16LE stream (len32le frames)
 */

const upload = multer({ storage: multer.memoryStorage() });

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);
const VOICES_DIR = "E:\\AI\\piper-tts\\voices";
const DATA_DIR = path.resolve(__dirname, "../../data");
const VOICE_CONFIG_PATH = path.join(DATA_DIR, "voice_config.json");
const TTS_CONFIG_PATH = path.join(DATA_DIR, "tts.json");

const QWEN_CUSTOM_DESC_PATH = path.join(DATA_DIR, "qwen_custom_voice.txt");

// Temp files for Piper fallback
const TMP_DIR = path.join(DATA_DIR, "tmp");
const TMP_PIPER_TEXT = path.join(TMP_DIR, "piper_input.txt");
const TMP_PIPER_WAV = path.join(TMP_DIR, "piper_output.wav");

function readJsonSafe(filePath, fallback = null) {
  try {
    if (!fs.existsSync(filePath)) return fallback;
    return JSON.parse(fs.readFileSync(filePath, "utf8"));
  } catch {
    return fallback;
  }
}

function readTextSafe(p, fallback = "") {
  try {
    if (!fs.existsSync(p)) return fallback;
    const s = fs.readFileSync(p, "utf-8");
    return String(s || "").trim();
  } catch {
    return fallback;
  }
}

function writeJsonSafe(filePath, value) {
  fs.mkdirSync(path.dirname(filePath), { recursive: true });
  fs.writeFileSync(filePath, JSON.stringify(value, null, 2), "utf8");
}

function normalizeProvider(p) {
  const raw = String(p || "")
    .trim()
    .toLowerCase();
  if (raw === "qwen") return "qwen3";
  if (!raw) return "qwen3";
  return raw;
}

function normalizeVoice(v) {
  const raw = String(v || "")
    .trim()
    .toLowerCase();
  if (!raw) return "ryan";
  return raw;
}

function getVoiceConfig() {
  const vc = readJsonSafe(VOICE_CONFIG_PATH, null);
  if (vc && typeof vc === "object") return vc;

  const tts = readJsonSafe(TTS_CONFIG_PATH, null);
  if (tts && typeof tts === "object") return tts;

  // Safe default: Qwen3 primary + Piper fallback
  return {
    provider: "xtts",
    voice: "ryan",
    fallbackProvider: "piper",
    fallbackVoice: "alba",
  };
}

function setVoiceConfig(next) {
  const cur = getVoiceConfig();
  const merged = { ...cur, ...(next && typeof next === "object" ? next : {}) };

  merged.provider = normalizeProvider(merged.provider);
  merged.voice = normalizeVoice(merged.voice);
  merged.fallbackProvider = normalizeProvider(
    merged.fallbackProvider || "piper"
  );
  merged.fallbackVoice = String(merged.fallbackVoice || "alba")
    .trim()
    .toLowerCase();

  writeJsonSafe(VOICE_CONFIG_PATH, merged);
  return merged;
}

function listVoices() {
  // Providers/voices we expose to the UI.
  return [
    { provider: "xtts",  voice: "curie" },
    { provider: "piper", voice: "alba" },
    { provider: "piper", voice: "amy" },
    { provider: "piper", voice: "jarvis" },
  ];
}
function getQwenBaseUrl(cfg) {
  return (
    process.env.QWEN3_TTS_URL ||
    cfg?.qwen3?.baseUrl ||
    "http://127.0.0.1:5005"
  ).replace(/\/$/, "");
}

function emotionToInstruct(emotion, intensity) {
  const e = String(emotion || "neutral")
    .trim()
    .toLowerCase();
  const x = Number.isFinite(Number(intensity)) ? Number(intensity) : 0.35;

  if (e === "neutral") return "Neutral, natural.";
  if (e === "happy") return `Upbeat and warm (intensity ${x}).`;
  if (e === "sad") return `Soft and subdued (intensity ${x}).`;
  if (e === "angry") return `Firm and controlled (intensity ${x}).`;
  if (e === "excited") return `Energetic and lively (intensity ${x}).`;
  return `Match the emotion "${e}" (intensity ${x}).`;
}

function safeParseJsonBody(req) {
  // express.json() yields a plain object. express.raw() yields Buffer/Uint8Array.
  if (
    req &&
    req.body &&
    typeof req.body === "object" &&
    !Buffer.isBuffer(req.body) &&
    !(req.body instanceof Uint8Array)
  ) {
    return req.body;
  }

  const raw = req?.body;
  if (!raw) return {};

  const tryDecode = (enc) => {
    const s = Buffer.from(raw)
      .toString(enc)
      .trim()
      .replace(/^\uFEFF/, "");
    return JSON.parse(s);
  };

  try {
    return tryDecode("utf8");
  } catch {
    // PowerShell curl.exe can sometimes send UTF-16LE.
    return tryDecode("utf16le");
  }
}

function writeLen32Frame(res, buf) {
  const len = buf ? buf.length : 0;
  const hdr = Buffer.alloc(4);
  hdr.writeUInt32LE(len, 0);
  res.write(hdr);
  if (len > 0) res.write(buf);
}

function chunkTextForStreaming(text, maxChars) {
  const SENT_SPLIT_RE = /(?<=[\.\!\?])\s+/;
  const s = String(text || "")
    .trim()
    .replace(/\s+/g, " ");
  if (!s) return [];
  if (s.length <= maxChars) return [s];

  const sentences = s.split(SENT_SPLIT_RE);
  const parts = [];
  let cur = "";

  for (const sentRaw of sentences) {
    const sent = String(sentRaw || "").trim();
    if (!sent) continue;

    if (sent.length > maxChars) {
      for (let i = 0; i < sent.length; i += maxChars) {
        parts.push(sent.slice(i, i + maxChars).trim());
      }
      cur = "";
      continue;
    }

    if (!cur) cur = sent;
    else if (cur.length + 1 + sent.length <= maxChars) cur = `${cur} ${sent}`;
    else {
      parts.push(cur);
      cur = sent;
    }
  }

  if (cur) parts.push(cur);
  return parts.filter(Boolean);
}

// ---------- Piper fallback (local piper.exe) ----------

function resolvePiperVoicePath(name) {
  const v = String(name || "alba")
    .trim()
    .toLowerCase();

  const map = {
    alba: "en_GB-alba-medium.onnx",
    amy: "en_US-amy-medium.onnx",
    jarvis: "en_US-ryan-medium.onnx",
  };

  const file = map[v] || map.alba;

  const full = path.join(VOICES_DIR, file);

  if (!fs.existsSync(full)) {
    throw new Error(`Piper voice not found: ${full}`);
  }

  return full;
}

async function synthesizePiperWav({ text, voice }) {
  if (!PIPER_EXE || !fs.existsSync(PIPER_EXE)) {
    throw new Error(
      `Piper TTS fallback not available (PIPER_EXE missing): ${
        PIPER_EXE || "(null)"
      }`
    );
  }

  const modelPath = resolvePiperVoicePath(voice);
  if (!modelPath || !fs.existsSync(modelPath)) {
    throw new Error(`Piper voice model missing: ${modelPath || "(null)"}`);
  }

  fs.mkdirSync(path.dirname(TMP_PIPER_TEXT), { recursive: true });
  fs.mkdirSync(path.dirname(TMP_PIPER_WAV), { recursive: true });
  fs.writeFileSync(TMP_PIPER_TEXT, String(text || ""), "utf8");

  // piper.exe reads text from stdin; we feed the file contents
  const stdinText = fs.readFileSync(TMP_PIPER_TEXT);

  await new Promise((resolve, reject) => {
    const args = ["-m", modelPath, "-f", TMP_PIPER_WAV];
    const p = spawn(PIPER_EXE, args, { stdio: ["pipe", "pipe", "pipe"] });

    let stderr = "";
    p.stderr.on("data", (d) => (stderr += d.toString()));
    p.on("error", (e) => reject(e));
    p.on("close", (code) => {
      if (code === 0) return resolve();
      reject(
        new Error(`piper.exe exited ${code}: ${stderr || "unknown error"}`)
      );
    });

    p.stdin.write(stdinText);
    p.stdin.end();
  });

  const wav = fs.readFileSync(TMP_PIPER_WAV);
  return wav;
}

// ---------- Qwen primary ----------

async function synthesizeQwenWav({
  cfg,
  text,
  voice,
  emotion,
  intensity,
  instruct,
}) {
  const baseUrl = getQwenBaseUrl(cfg);
  const url = `${baseUrl}/speak`;

  const baseInstruct = String(instruct || emotionToInstruct(emotion, intensity));

  // Custom voice description is stored in a local file so you can edit it safely.
  // This keeps UI simple and avoids losing it during HTML changes.
  const customDesc = readTextSafe(QWEN_CUSTOM_DESC_PATH, "");

  // For Qwen "custom" mode, send custom_description so the server can apply voice design/caching.
  // For other voices, omit it.
  const payload = {
    text: String(text || ""),
    voice: String(voice || "ryan"),
    language: "english",
    instruct: baseInstruct,
  };

  if (String(voice || "").toLowerCase() === "custom" && customDesc) {
    payload.custom_description = customDesc;
  }

  const body = JSON.stringify(payload);

  const resp = await fetch(url, {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body,
  });

  if (!resp.ok) {
    const errText = await resp.text().catch(() => "");
    throw new Error(
      `Qwen3 TTS HTTP ${resp.status}: ${errText || resp.statusText}`
    );
  }

  const ab = await resp.arrayBuffer();
  return Buffer.from(ab);
}

/**
 * Main synthesis path:
 *  - try Qwen3
 *  - fallback to Piper (Alba) if Qwen fails
 */
function getXttsBaseUrl(cfg) {
  return (
    process.env.XTTS_URL ||
    process.env.XTTS_BASE_URL ||
    cfg?.xtts?.base_url ||
    cfg?.xtts?.baseUrl ||
    "http://127.0.0.1:5055"
  ).replace(/\/$/, "");
}

async function synthesizeXTTSWav(text, cfg) {
  const baseUrl = getXttsBaseUrl(cfg);

  // Many XTTS demo servers expose /speak. Some use /tts. We'll try a few.
  const endpoints = ["/speak", "/tts", "/api/tts"];

  const payload = {
    text: String(text || ""),
    voice: cfg?.voice || "curie",
    // Our XTTS microservice expects `ref` (name of a wav in refs_dir, without extension)
    ref: (cfg?.emotion || "neutral"),
    // keep these for backwards-compat/debug (server ignores unknown keys)
    emotion: cfg?.emotion || "neutral",
    emotion_intensity:
      Number.isFinite(Number(cfg?.emotion_intensity)) ?
        Number(cfg.emotion_intensity) :
        0.8,
    refs_dir: cfg?.xtts?.refs_dir,
    model_dir: cfg?.xtts?.model_dir,
  };

  let lastErr = null;

  for (const ep of endpoints) {
    try {
      const r = await fetch(baseUrl + ep, {
        method: "POST",
        headers: { "content-type": "application/json" },
        body: JSON.stringify(payload),
      });

      if (!r.ok) {
        const msg = await r.text().catch(() => "");
        throw new Error(`XTTS ${ep} HTTP ${r.status}: ${msg}`);
      }

      const ab = await r.arrayBuffer();
      const buf = Buffer.from(ab);
      if (!buf || buf.length < 128) throw new Error(`XTTS ${ep} returned empty audio`);
      return buf;
    } catch (e) {
      lastErr = e;
    }
  }

  throw lastErr || new Error("XTTS request failed.");
}

async function synthesizeWavBuffer(text, cfg) {
  const provider = normalizeProvider(cfg?.provider);

  // Prefer XTTS when selected, fallback to Piper.
  if (provider === "xtts") {
    try {
      return await synthesizeXTTSWav(text, cfg);
    } catch (e) {
      // Fallback if XTTS errors out for any reason.
      const fbVoice = cfg?.fallbackVoice || "alba";
      return await synthesizePiperWav(text, fbVoice);
    }
  }

  if (provider === "piper") {
    return await synthesizePiperWav(text, normalizeVoice(cfg?.voice));
  }

  // Legacy / experimental: Qwen3 (kept for compatibility if present in config).
  if (provider === "qwen3") {
    try {
      return await synthesizeQwenWav(
        text,
        cfg?.speaker_wav || "",
        cfg?.emotion || "neutral",
        cfg?.emotion_intensity ?? 0.35
      );
    } catch (e) {
      const fbVoice = cfg?.fallbackVoice || "alba";
      return await synthesizePiperWav(text, fbVoice);
    }
  }

  // Unknown provider -> Piper fallback
  const fbVoice = cfg?.fallbackVoice || "alba";
  return await synthesizePiperWav(text, fbVoice);
}
export function voiceRoutes() {
  const r = Router();

  // ---- STT ----
  r.post("/voice/transcribe", upload.single("audio"), async (req, res) => {
    try {
      if (!req.file || !req.file.buffer) {
        return res.status(400).json({ ok: false, error: "No audio uploaded" });
      }
      const text = await transcribeAudioBuffer(req.file.buffer);
      res.json({ ok: true, text });
    } catch (e) {
      res.status(500).json({ ok: false, error: String(e?.message || e) });
    }
  });

  // ---- Voice config ----
  r.get("/voice/config", (_req, res) => res.json(getVoiceConfig()));

  r.post("/voice/config", express.json({ limit: "128kb" }), (req, res) => {
    try {
      const next = setVoiceConfig(req.body || {});
      res.json({ ok: true, config: next });
    } catch (e) {
      res.status(500).json({ ok: false, error: String(e?.message || e) });
    }
  });

  r.get("/voice/voices", (_req, res) => res.json(listVoices()));

  // ---- Speak (returns WAV) ----
  r.post(
    "/voice/speak",
    // Parse body here; supports curl.exe UTF-16LE too
    express.raw({ type: "application/json", limit: "1mb" }),
    async (req, res) => {
      try {
        const payload = safeParseJsonBody(req);
        const {
          text = "",
          input = "",
          emotion = "neutral",
          intensity = 0.4,
          sessionId = null,
        } = payload || {};

        const finalText = String(text || input || "");
        if (!finalText.trim()) {
          return res
            .status(400)
            .json({ ok: false, error: "Missing input text" });
        }

        const wav = await synthesizeWavBuffer({
          text: finalText,
          emotion,
          intensity,
          sessionId,
        });

        res.setHeader("Content-Type", "audio/wav");
        res.setHeader("Cache-Control", "no-store");
        res.status(200).send(wav);
      } catch (e) {
        console.log("[voice] /voice/speak error", String(e?.stack || e));
        res.status(500).json({ ok: false, error: String(e?.message || e) });
      }
    }
  );

  // ---- Stream (framed PCM16LE) ----
  r.post(
    "/voice/stream",
    express.raw({ type: "application/json", limit: "1mb" }),
    async (req, res) => {
      try {
        const body = safeParseJsonBody(req);
        const { text = "", emotion = "neutral", intensity = 0.4 } = body || {};
        const finalText = String(text || "");
        if (!finalText.trim()) {
          return res
            .status(400)
            .json({ ok: false, error: "Missing input text" });
        }

        await streamChunkedTtsAsFramedPcm({
          text: finalText,
          emotion,
          intensity,
          res,
        });
      } catch (e) {
        console.log("[voice] /voice/stream error", String(e?.stack || e));
        try {
          res.status(500).end();
        } catch {}
      }
    }
  );

  return r;
}

import fs from "fs";
import path from "path";
import os from "os";
import http from "http";
import https from "https";
import { spawn } from "child_process";
import { fileURLToPath } from "url";
import { PATHS } from "../../config/paths.js";
import { normalizeEmotion, makeSpoken, clamp01 } from "../persona.js";

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

const VOICE_CFG_PATH = path.join(PATHS.DATA_DIR, "voice_config.json");

// Providers supported by this hub build:
const PROVIDERS = ["piper", "xtts"];

const DEFAULT_CFG = {
  provider: "xtts",
  voice: "curie",
  speaker_wav: "",
  emotion: "serious_neutral",
  emotion_intensity: 0.8,
  xtts: {
    base_url: "http://127.0.0.1:5055",
    model_dir: "E:\\AI\\piper_voice_curie",
    refs_dir: "E:\\AI\\piper_voice_curie\\refs",
  },
};

function readJson(p, fallback) {
  try {
    if (!fs.existsSync(p)) return fallback;
    return JSON.parse(fs.readFileSync(p, "utf8"));
  } catch {
    return fallback;
  }
}

function writeJson(p, obj) {
  fs.mkdirSync(path.dirname(p), { recursive: true });
  fs.writeFileSync(p, JSON.stringify(obj, null, 2), "utf8");
}

export async function getVoiceConfig() {
  const cfg = readJson(VOICE_CFG_PATH, DEFAULT_CFG);
  // sanity
  if (!PROVIDERS.includes(cfg.provider)) cfg.provider = "piper";
  return cfg;
}

export async function setVoiceConfig(next) {
  const cur = await getVoiceConfig();
  const merged = {
    ...cur,
    ...(next || {}),
    xtts: { ...(cur.xtts || {}), ...((next || {}).xtts || {}) },
  };
  if (!PROVIDERS.includes(merged.provider)) merged.provider = cur.provider;
  writeJson(VOICE_CFG_PATH, merged);
  return merged;
}

/** List voices the UI can select. */
export function listVoices() {
  return [
    { id: "curie", label: "Curie (XTTS)", provider: "xtts" },
    { id: "amy", label: "Amy (Piper)", provider: "piper" },
    { id: "jarvis", label: "Jarvis (Piper)", provider: "piper" },
    { id: "alba", label: "Alba (Piper)", provider: "piper" },
  ];
}

function httpRequest(url, { method = "GET", headers = {}, body = null, timeoutMs = 120000 } = {}) {
  return new Promise((resolve, reject) => {
    const u = new URL(url);
    const lib = u.protocol === "https:" ? https : http;
    const req = lib.request(
      {
        protocol: u.protocol,
        hostname: u.hostname,
        port: u.port,
        path: u.pathname + (u.search || ""),
        method,
        headers,
      },
      (res) => {
        const chunks = [];
        res.on("data", (d) => chunks.push(d));
        res.on("end", () => {
          const buf = Buffer.concat(chunks);
          resolve({ status: res.statusCode || 0, headers: res.headers, body: buf });
        });
      }
    );
    req.on("error", reject);
    req.setTimeout(timeoutMs, () => {
      req.destroy(new Error("HTTP timeout"));
    });
    if (body) req.write(body);
    req.end();
  });
}

function pickRefForEmotion(cfg, emotionNorm) {
  // Try exact emotion first
  const refsDir = cfg?.xtts?.refs_dir || DEFAULT_CFG.xtts.refs_dir;
  const asPath = (name) => path.join(refsDir, `${name}.wav`);

  const candidates = [
    emotionNorm,
    // fallbacks by coarse group
    emotionNorm.startsWith("angry") ? "angry_stern" : null,
    emotionNorm.startsWith("sad") ? "sad_loss" : null,
    emotionNorm.startsWith("happy") ? "happy_cheerful" : null,
    emotionNorm.startsWith("excited") ? "excited_sincere" : null,
    emotionNorm.startsWith("curious") ? "curious_thoughtful" : null,
    emotionNorm.startsWith("anguish") ? "anguish_sad" : null,
    emotionNorm.startsWith("serious") ? "serious_neutral" : null,
    "serious_neutral",
  ].filter(Boolean);

  for (const c of candidates) {
    const p = asPath(c);
    if (fs.existsSync(p)) return p;
  }
  // last resort: any wav
  try {
    const wavs = fs.readdirSync(refsDir).filter((f) => f.toLowerCase().endsWith(".wav"));
    if (wavs.length) return path.join(refsDir, wavs[0]);
  } catch {}
  return "";
}

async function synthesizeXTTS(text, { emotion, intensity } = {}) {
  const cfg = await getVoiceConfig();
  const base = cfg?.xtts?.base_url || DEFAULT_CFG.xtts.base_url;
  const emotionNorm = normalizeEmotion(emotion || cfg.emotion || "serious_neutral");
  const ref = pickRefForEmotion(cfg, emotionNorm);

  const payload = {
    text,
    language: "en",
    emotion: emotionNorm,
    ref: ref || undefined,
    // Some knobs you can tweak later:
    temperature: 0.7,
    top_p: 0.85,
    top_k: 50,
    repetition_penalty: 2.0,
    length_penalty: 1.0,
    intensity: clamp01(intensity ?? cfg.emotion_intensity ?? 0.8),
  };

  const r = await httpRequest(`${base.replace(/\/+$/, "")}/speak`, {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: Buffer.from(JSON.stringify(payload), "utf8"),
    timeoutMs: 180000,
  });

  if (r.status !== 200) {
    const msg = r.body?.toString("utf8").slice(0, 4000);
    throw new Error(`XTTS server error (${r.status}): ${msg}`);
  }

  // Save to a temp wav for playback
  const outPath = path.join(os.tmpdir(), `piper_xtts_${Date.now()}.wav`);
  fs.writeFileSync(outPath, r.body);
  return outPath;
}

async function synthesizePiper(text, voiceId) {
  // voiceId maps to a model path in paths.js
  const modelPath = PATHS.PIPER_VOICES[voiceId] || PATHS.PIPER_VOICES["amy"];
  if (!modelPath || !fs.existsSync(modelPath)) {
    throw new Error(`Piper voice model not found for "${voiceId}". Check PATHS.PIPER_VOICES.`);
  }

  const outPath = path.join(os.tmpdir(), `piper_${voiceId}_${Date.now()}.wav`);

  // Piper typically writes raw wav to stdout; use piper.exe -m model -f out.wav
  await new Promise((resolve, reject) => {
    const args = ["-m", modelPath, "-f", outPath];
    const p = spawn(PATHS.PIPER_EXE, args, { stdio: ["pipe", "pipe", "pipe"] });

    let err = "";
    p.stderr.on("data", (d) => (err += String(d)));
    p.on("error", reject);
    p.on("close", (code) => {
      if (code !== 0) return reject(new Error(`piper exited ${code}: ${err}`));
      resolve();
    });

    p.stdin.write(text, "utf8");
    p.stdin.end();
  });

  return outPath;
}

async function playWavBlocking(wavPath) {
  // Uses ffplay if available; otherwise return wav path and let client play it.
  if (!PATHS.FFPLAY_EXE || !fs.existsSync(PATHS.FFPLAY_EXE)) return { played: false, wavPath };

  await new Promise((resolve) => {
    const p = spawn(PATHS.FFPLAY_EXE, ["-autoexit", "-nodisp", wavPath], { stdio: "ignore" });
    p.on("close", () => resolve());
    p.on("error", () => resolve());
  });

  return { played: true, wavPath };
}

// Simple queue (prevents overlapping speech)
const queue = [];
let playing = false;

export async function speakQueued(text, opts = {}) {
  return new Promise((resolve, reject) => {
    queue.push({ text, opts, resolve, reject });
    pumpQueue();
  });
}

async function pumpQueue() {
  if (playing) return;
  const item = queue.shift();
  if (!item) return;
  playing = true;

  try {
    const cfg = await getVoiceConfig();
    const provider = cfg.provider || "piper";

    // Make it slightly more "spoken" before TTS.
    const spoken = makeSpoken(item.text);

    let wavPath;
    if (provider === "xtts") {
      wavPath = await synthesizeXTTS(spoken, item.opts);
    } else {
      // Piper voice selection: cfg.voice is "amy"/"jarvis"/"alba"
      wavPath = await synthesizePiper(spoken, cfg.voice || "amy");
    }

    const played = await playWavBlocking(wavPath);
    item.resolve({ provider, wavPath, ...played });
  } catch (e) {
    item.reject(e);
  } finally {
    playing = false;
    setImmediate(pumpQueue);
  }
}
